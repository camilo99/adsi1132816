
<style>
	body{
		background: -webkit-linear-gradient(right, #333, #fff);
	}
</style>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	

<?php  
	require 'load.php';
	require 'model.php';
	require 'controller.php';

	new Controller();
?>
</body>
</html>